'use strict';
/**
 * Screenshot learning.
 *
 * Capture method: Electron's built-in desktopCapturer (no external binaries,
 * no .bat helper). Works on Windows/macOS/Linux from the main process.
 *
 * Strategy (privacy-respecting and storage-light):
 *  1. Poll the screen at a modest interval, but only PROCESS a frame when it is
 *     "meaningfully different" from the previous one — measured by a downscaled
 *     perceptual hash (aHash). Idle screens cost almost nothing.
 *  2. On a meaningful change: run OCR locally, then ask the LLM to extract a
 *     small STRUCTURED record (app, task, errors, buttons, commands, step).
 *  3. Store only the structured text in memory. The raw image is discarded.
 *
 * Everything here is gated by Settings (screenshotLearning) and the privacy
 * exclusion list. The active app/window title check is a hook left for the
 * platform-specific module (see active-window note in DEVELOPER_GUIDE).
 */
const config = require('./config');
const privacy = require('./privacy');
const memory = require('./memory');
const ocr = require('./ocr');
const llm = require('./llm');
const activeWindow = require('./activeWindow');
const { log } = require('./logger');

let timer = null;
let lastHash = null;
let busy = false;
let onEvent = () => {};

/**
 * Capture the primary display as a PNG buffer using Electron's desktopCapturer.
 * Requires the Electron app to be ready; only used from the main process.
 */
async function captureScreen() {
  const { desktopCapturer, screen } = require('electron');
  const primary = screen.getPrimaryDisplay();
  const { width, height } = primary.size;
  const scale = primary.scaleFactor || 1;

  // Cap the captured resolution so OCR stays fast but legible.
  const maxW = 1920;
  const fullW = Math.round(width * scale);
  const fullH = Math.round(height * scale);
  const thumbW = Math.min(fullW, maxW);
  const thumbH = Math.round((thumbW / fullW) * fullH);

  const sources = await desktopCapturer.getSources({
    types: ['screen'],
    thumbnailSize: { width: thumbW, height: thumbH }
  });
  if (!sources || !sources.length) throw new Error('no screen source available');

  // Prefer the primary screen if its display_id matches; otherwise take first.
  let src = sources[0];
  const primaryId = String(primary.id);
  for (const s of sources) {
    if (String(s.display_id) === primaryId) { src = s; break; }
  }

  const png = src.thumbnail.toPNG();
  if (!png || !png.length) throw new Error('empty screen capture');
  return png;
}

/** 16x16 grayscale average hash from a screenshot buffer (via sharp). */
async function perceptualHash(buf) {
  const sharp = require('sharp');
  const size = 16;
  const raw = await sharp(buf).resize(size, size, { fit: 'fill' }).grayscale().raw().toBuffer();
  let sum = 0;
  for (let i = 0; i < raw.length; i++) sum += raw[i];
  const avg = sum / raw.length;
  const bits = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bits[i] = raw[i] >= avg ? 1 : 0;
  return bits;
}

function hammingRatio(a, b) {
  if (!a || !b || a.length !== b.length) return 1;
  let diff = 0;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) diff++;
  return diff / a.length;
}

const EXTRACT_PROMPT = `Extract a compact structured record from this on-screen text.
Return STRICT JSON only, no prose, with keys:
{"application":"","current_task":"","errors":[],"buttons":[],"commands":[],"workflow_step":""}
Keep each value short. Use [] when nothing applies.`;

async function extractStructured(text) {
  if (!text || text.length < 12) return null;
  try {
    const { text: out } = await llm.chat({
      system: EXTRACT_PROMPT,
      messages: [{ role: 'user', content: text.slice(0, 4000) }]
    });
    const clean = out.replace(/```json|```/g, '').trim();
    const json = JSON.parse(clean);
    return json;
  } catch (e) {
    log.warn('Structured extraction failed, storing raw OCR snippet:', e.message);
    return null;
  }
}

/**
 * Surface a detected on-screen error: look for a past fix in memory/corrections,
 * show a desktop notification, and emit an event for the UI.
 */
async function raiseErrorAlert(errors, structured) {
  const summary = errors.join('; ').slice(0, 200);
  let suggestion = '';
  try {
    const hits = await memory.retrieve(summary, { topK: 3 });
    const best = hits.find((h) => h.kind === 'correction') || hits[0];
    if (best) suggestion = String(best.content).slice(0, 240);
  } catch (_) {}

  try {
    if (config.read('notifications')) {
      const { Notification } = require('electron');
      const body = suggestion
        ? `${summary}\n\nSeen before — suggestion: ${suggestion}`
        : summary;
      new Notification({ title: 'JARVIS: error detected on screen', body }).show();
    }
  } catch (_) {}

  onEvent({
    type: 'error-detected',
    app: structured?.application || null,
    task: structured?.current_task || null,
    errors,
    suggestion
  });
  log.info('Error alert raised: ' + summary);
}

async function processFrame() {
  if (busy) return;
  busy = true;
  try {
    const buf = await captureScreen();
    const hash = await perceptualHash(buf);
    const changed = hammingRatio(lastHash, hash);
    const threshold = config.read('screenshotChangeThreshold') ?? 0.12;

    if (lastHash && changed < threshold) {
      busy = false;
      return; // not a meaningful change
    }
    lastHash = hash;

    // Active-app gating (#1): skip excluded apps / sensitive window titles.
    const win = await activeWindow.current(); // { app, title } on Windows; {} elsewhere
    const ctx = { app: win.app, title: win.title };
    if (!privacy.allow(ctx)) {
      log.info(`Skipped capture (excluded): ${win.app || ''} ${win.title || ''}`.trim());
      busy = false;
      return;
    }

    const text = await ocr.recognize(buf);
    if (!text) {
      busy = false;
      return;
    }

    const structured = await extractStructured(text);
    const activeTag = config.read('activeTag') || null; // project label (#6)
    const errors = (structured && structured.errors) || [];
    const hasError = Array.isArray(errors) && errors.filter(Boolean).length > 0;

    const content = structured
      ? `Application: ${structured.application}\n` +
        `Task: ${structured.current_task}\n` +
        `Errors: ${(structured.errors || []).join('; ')}\n` +
        `Buttons: ${(structured.buttons || []).join('; ')}\n` +
        `Commands: ${(structured.commands || []).join('; ')}\n` +
        `Workflow step: ${structured.workflow_step}`
      : text.slice(0, 1500);

    await memory.ingest({
      kind: 'ocr',
      source: structured?.application || win.app || 'screen',
      title: structured?.current_task || win.title || 'Screen capture',
      content,
      tag: activeTag,
      pinned: hasError ? 1 : 0, // keep errors around (skipped by auto-cleanup)
      metadata: {
        structured: !!structured,
        changeRatio: Number(changed.toFixed(3)),
        app: win.app || null,
        isError: hasError,
        errors: hasError ? errors.filter(Boolean) : []
      }
    });

    // Error detection (#7): alert + suggest a fix from past memory/corrections.
    if (hasError && config.read('errorAlerts')) {
      await raiseErrorAlert(errors.filter(Boolean), structured);
    }

    onEvent({ type: 'screenshot-learned', app: structured?.application, task: structured?.current_task });
    log.info('Learned from screen change. structured=' + !!structured + (hasError ? ' (error detected)' : ''));
  } catch (e) {
    log.warn('Screenshot frame error:', e.message);
  } finally {
    busy = false;
  }
}

function start(emit) {
  if (timer) return;
  onEvent = emit || (() => {});
  const interval = Math.max(config.read('screenshotMinIntervalMs') || 4000, 2000);
  timer = setInterval(processFrame, interval);
  log.info(`Screenshot learning started (interval ${interval}ms).`);
}

function stop() {
  if (timer) clearInterval(timer);
  timer = null;
  lastHash = null;
  log.info('Screenshot learning stopped.');
}

function isRunning() {
  return !!timer;
}

module.exports = { start, stop, isRunning, _processFrame: processFrame };
